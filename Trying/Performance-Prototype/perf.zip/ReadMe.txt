Installation node,grunt and typescript with npm.

1) install -g node
2) init
3) install -g grunt
4) install -g grunt-cli
5) install -g typescript
6) install -g grunt-typescript
7) install -g grunt-contrib-watch
8) install -g grunt-contrib-connect
9) install -g grunt-open
10) run grunt


http://jessefreeman.com/dev-techniques/automating-typescript-with-node-and-grunt/